package com.khandani.silverglobesolutions.cazzysimple_networking;

/**
 * Created by silverglobesolutions on 25/10/17.
 */

public interface ResponseHandler {

    public void getResponse(ServerResponseWrapper serverResponseWrapper);


}
